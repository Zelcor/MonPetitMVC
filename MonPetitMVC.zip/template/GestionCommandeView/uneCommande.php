<?php
include_once PATH_VIEW . "header.html";
var_dump($uneCommande);
echo "id du Cliente : " . $uneCommande->getIdClient();
include_once PATH_VIEW . "footer.html";

