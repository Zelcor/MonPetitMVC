<?php
include_once PATH_VIEW . "header.html";
var_dump($unClient);
echo "Nom du client : " . $unClient->getNomCli();
include_once PATH_VIEW . "footer.html";
