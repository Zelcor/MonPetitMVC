<?php

namespace APP\Repository;

use Tools\Repository;

class ClientRepository extends Repository{
    public function __construct($entity) {
        parent::__construct($entity);
    }
}